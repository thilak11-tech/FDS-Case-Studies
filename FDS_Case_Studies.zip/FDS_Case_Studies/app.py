import joblib
import pandas as pd
import streamlit as st

artifact = joblib.load("model/titanic_model.joblib")
model = artifact["model"]
columns = artifact["columns"]

st.set_page_config(page_title="Titanic Survival Predictor")
st.title("Titanic Survival Predictor")

pclass = st.selectbox("Passenger Class", [1, 2, 3], index=2)
sex = st.radio("Sex", ["Male", "Female"], horizontal=True)
age = st.slider("Age (years)", 0, 80, 30)
sibsp = st.number_input("Siblings or Spouses Aboard", min_value=0, max_value=8, value=0)
parch = st.number_input("Parents or Children Aboard", min_value=0, max_value=6, value=0)
fare = st.number_input("Ticket Fare (pounds)", min_value=0.0, max_value=520.0, value=32.0)
port = st.selectbox("Port of Embarkation", ["Southampton", "Cherbourg", "Queenstown"])

if st.button("Predict"):
    row = {
        "Pclass": pclass,
        "Sex": 1 if sex == "Female" else 0,
        "Age": age,
        "SibSp": sibsp,
        "Parch": parch,
        "Fare": fare,
        "Embarked_Q": 1 if port == "Queenstown" else 0,
        "Embarked_S": 1 if port == "Southampton" else 0,
    }
    frame = pd.DataFrame([row])[columns]
    probability = model.predict_proba(frame)[0, 1]
    st.metric("Survival Probability", f"{probability:.1%}")
    if probability >= 0.5:
        st.success("The passenger is predicted to survive.")
    else:
        st.error("The passenger is predicted not to survive.")
