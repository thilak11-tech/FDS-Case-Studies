import os
import warnings
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from matplotlib.colors import PowerNorm
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, roc_curve, confusion_matrix, classification_report)

warnings.filterwarnings("ignore")
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 40)
plt.rcParams.update({
    "figure.dpi": 100,
    "font.family": "serif",
    "text.color": "black",
    "axes.edgecolor": "black",
    "axes.labelcolor": "black",
    "xtick.color": "black",
    "ytick.color": "black",
    "axes.titleweight": "bold",
    "axes.titlesize": 12,
})
os.makedirs("outputs/figures", exist_ok=True)
os.makedirs("model", exist_ok=True)
RANDOM_STATE = 42


def save_figure(name):
    plt.savefig(f"outputs/figures/{name}.png", dpi=200, bbox_inches="tight")


def draw_confusion(ax, matrix, labels, title):
    ax.imshow(matrix, cmap="Greys", norm=PowerNorm(gamma=0.4, vmin=0, vmax=matrix.max()))
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(labels)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted Label")
    ax.set_ylabel("Actual Label")
    ax.set_title(title)
    limit = matrix.max() * 0.35
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{matrix[i, j]:,}", ha="center", va="center", fontsize=13,
                    fontweight="bold", color="white" if matrix[i, j] > limit else "black")

titanic = pd.read_csv("data/titanic.csv")
print(titanic.head(10))

print(titanic.shape)
titanic.info()
print(titanic.describe())
print(titanic[["Sex", "Embarked"]].describe())

missing = titanic.isnull().sum()
missing_table = pd.DataFrame({"Missing": missing, "Percent": (missing / len(titanic) * 100).round(2)})
print(missing_table)
print(titanic["Survived"].value_counts())
print(titanic["Survived"].value_counts(normalize=True).round(3))

for column in ["Sex", "Pclass", "Embarked"]:
    print(titanic.groupby(column)["Survived"].agg(["count", "mean"]).round(3))
    print()

fig, axes = plt.subplots(1, 2, figsize=(11, 4))
axes[0].hist(titanic["Age"].dropna(), bins=20, color="0.6", edgecolor="black")
axes[0].set_title("Distribution of Passenger Age")
axes[0].set_xlabel("Age (years)")
axes[0].set_ylabel("Number of Passengers")
axes[1].hist(titanic["Fare"], bins=30, color="0.6", edgecolor="black")
axes[1].set_title("Distribution of Ticket Fare")
axes[1].set_xlabel("Fare (pounds)")
axes[1].set_ylabel("Number of Passengers")
plt.tight_layout()
save_figure("titanic_histograms")
plt.show()

fig, axes = plt.subplots(1, 3, figsize=(14, 4))
for ax, column in zip(axes, ["Sex", "Pclass", "Embarked"]):
    counts = pd.crosstab(titanic[column], titanic["Survived"])
    counts.plot(kind="bar", ax=ax, color=["0.8", "0.15"], edgecolor="black", rot=0)
    ax.set_title(f"Survival Count by {column}")
    ax.set_xlabel(column)
    ax.set_ylabel("Number of Passengers")
    ax.legend(["Did not survive", "Survived"])
plt.tight_layout()
save_figure("titanic_survival_groups")
plt.show()

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
sns.boxplot(data=titanic, x="Survived", y="Age", ax=axes[0], color="0.8", linecolor="black")
axes[0].set_xticks([0, 1])
axes[0].set_xticklabels(["Did not survive", "Survived"])
axes[0].set_title("Age of Passengers by Survival")
axes[0].set_xlabel("Survival Outcome")
axes[0].set_ylabel("Age (years)")
sns.boxplot(data=titanic, x="Pclass", y="Fare", ax=axes[1], color="0.8", linecolor="black")
axes[1].set_title("Ticket Fare by Passenger Class")
axes[1].set_xlabel("Passenger Class")
axes[1].set_ylabel("Fare (pounds)")
plt.tight_layout()
save_figure("titanic_boxplots")
plt.show()

pair = sns.pairplot(titanic[["Survived", "Age", "Fare", "Pclass", "SibSp"]].dropna(), hue="Survived",
                    palette={0: "0.7", 1: "0.0"}, diag_kind="hist", markers=["o", "s"],
                    plot_kws={"alpha": 0.6, "edgecolor": "black", "linewidth": 0.3})
pair.figure.suptitle("Pair Plot of Selected Titanic Features", y=1.02, fontweight="bold")
pair.savefig("outputs/figures/titanic_pairplot.png", dpi=150, bbox_inches="tight")
plt.show()

corr_data = titanic[["Survived", "Pclass", "Age", "SibSp", "Parch", "Fare"]].copy()
corr_data["Sex"] = titanic["Sex"].map({"male": 0, "female": 1})
corr = corr_data.corr()
print(corr["Survived"].sort_values(ascending=False).round(3))
plt.figure(figsize=(7.5, 6))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="Greys", linewidths=0.5, linecolor="black",
            cbar_kws={"label": "Correlation Coefficient"})
plt.title("Correlation Heatmap of Titanic Features")
plt.xlabel("Features")
plt.ylabel("Features")
save_figure("titanic_correlation")
plt.show()

data = titanic.copy()
age_median = float(data["Age"].median())
embarked_mode = data["Embarked"].mode()[0]
print(age_median, embarked_mode)
data["Age"] = data["Age"].fillna(age_median)
data["Embarked"] = data["Embarked"].fillna(embarked_mode)
data = data.drop(columns=["PassengerId", "Name", "Ticket", "Cabin"])
print(data.isnull().sum())

data["Sex"] = data["Sex"].map({"male": 0, "female": 1})
data = pd.get_dummies(data, columns=["Embarked"], drop_first=True, dtype=int)
print(data.head(10))
print(data.dtypes)

X = data.drop(columns="Survived")
y = data["Survived"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y)
print(X_train.shape, X_test.shape)
print(y_train.value_counts(normalize=True).round(3))
print(y_test.value_counts(normalize=True).round(3))

log_model = LogisticRegression(C=np.inf, max_iter=10000)
log_model.fit(X_train, y_train)
joblib.dump({"model": log_model, "columns": list(X.columns), "age_median": age_median},
            "model/titanic_model.joblib")
print(log_model.intercept_)
print(pd.Series(log_model.coef_[0], index=X.columns).round(4))

y_pred = log_model.predict(X_test)
y_prob = log_model.predict_proba(X_test)[:, 1]
titanic_metrics = pd.DataFrame({
    "Metric": ["Accuracy", "Precision", "Recall", "F1-Score", "ROC-AUC"],
    "Score": [accuracy_score(y_test, y_pred), precision_score(y_test, y_pred),
              recall_score(y_test, y_pred), f1_score(y_test, y_pred), roc_auc_score(y_test, y_prob)],
}).round(4)
titanic_metrics.to_csv("outputs/titanic_metrics.csv", index=False)
print(titanic_metrics)
print(classification_report(y_test, y_pred, target_names=["Did not survive", "Survived"]))

folds = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
cv_accuracy = cross_val_score(LogisticRegression(C=np.inf, max_iter=10000), X, y, cv=folds, scoring="accuracy")
cv_auc = cross_val_score(LogisticRegression(C=np.inf, max_iter=10000), X, y, cv=folds, scoring="roc_auc")
print(cv_accuracy.round(4), cv_accuracy.mean().round(4), cv_accuracy.std().round(4))
print(cv_auc.round(4), cv_auc.mean().round(4), cv_auc.std().round(4))

titanic_cm = confusion_matrix(y_test, y_pred)
print(titanic_cm)
fig, ax = plt.subplots(figsize=(5, 4.5))
draw_confusion(ax, titanic_cm, ["Did not survive", "Survived"], "Confusion Matrix - Logistic Regression")
plt.tight_layout()
save_figure("titanic_confusion_matrix")
plt.show()

fpr, tpr, _ = roc_curve(y_test, y_prob)
titanic_auc = roc_auc_score(y_test, y_prob)
plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, color="black", linewidth=2, label=f"Logistic Regression (AUC = {titanic_auc:.3f})")
plt.plot([0, 1], [0, 1], linestyle="--", color="0.5", label="Random Guess (AUC = 0.500)")
plt.title("ROC Curve - Titanic Survival Prediction")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.legend(loc="lower right")
plt.tight_layout()
save_figure("titanic_roc_curve")
plt.show()

design = np.column_stack([np.ones(len(X_train)), X_train.values])
fitted = log_model.predict_proba(X_train)[:, 1]
weights = fitted * (1 - fitted)
covariance = np.linalg.inv(design.T @ (design * weights[:, None]))
parameters = np.concatenate([log_model.intercept_, log_model.coef_[0]])
std_error = np.sqrt(np.diag(covariance))
z_values = parameters / std_error
p_values = 2 * (1 - stats.norm.cdf(np.abs(z_values)))
coef_table = pd.DataFrame({
    "Feature": ["Intercept"] + list(X.columns),
    "Coefficient": parameters,
    "Std Error": std_error,
    "z-value": z_values,
    "p-value": p_values,
    "Odds Ratio": np.exp(parameters),
}).round(4)
coef_table.to_csv("outputs/titanic_coefficients.csv", index=False)
print(coef_table)

plot_table = coef_table[coef_table["Feature"] != "Intercept"].sort_values("Coefficient")
bar_colors = ["0.85" if value < 0 else "0.2" for value in plot_table["Coefficient"]]
bar_hatches = ["//" if value < 0 else "" for value in plot_table["Coefficient"]]
plt.figure(figsize=(8, 4.5))
bars = plt.barh(plot_table["Feature"], plot_table["Coefficient"], color=bar_colors, edgecolor="black")
for bar, hatch in zip(bars, bar_hatches):
    bar.set_hatch(hatch)
plt.axvline(0, color="black", linewidth=1)
plt.title("Logistic Regression Coefficients")
plt.xlabel("Coefficient Value (log-odds)")
plt.ylabel("Feature")
plt.tight_layout()
save_figure("titanic_coefficients")
plt.show()

saved = joblib.load("model/titanic_model.joblib")
sample = pd.DataFrame([{"Pclass": 1, "Sex": 1, "Age": 30, "SibSp": 0, "Parch": 0, "Fare": 80.0,
                        "Embarked_Q": 0, "Embarked_S": 0}])[saved["columns"]]
print(saved["model"].predict_proba(sample)[0, 1].round(4))
sample = pd.DataFrame([{"Pclass": 3, "Sex": 0, "Age": 25, "SibSp": 0, "Parch": 0, "Fare": 7.5,
                        "Embarked_Q": 0, "Embarked_S": 1}])[saved["columns"]]
print(saved["model"].predict_proba(sample)[0, 1].round(4))

bank = pd.read_csv("data/bank-additional-full.csv", sep=";")
print(bank.head(10))

print(bank.shape)
print(bank.dtypes)
print(bank.describe())

target_column = "y"
numeric_columns = bank.select_dtypes(include="number").columns.tolist()
categorical_columns = [c for c in bank.select_dtypes(exclude="number").columns if c != target_column]
print(target_column)
print(numeric_columns)
print(categorical_columns)

print(bank.isnull().sum().sum())
unknown_count = (bank[categorical_columns] == "unknown").sum()
unknown_table = pd.DataFrame({"Unknown": unknown_count,
                              "Percent": (unknown_count / len(bank) * 100).round(2)})
print(unknown_table)
print(bank.duplicated().sum())
print((bank["pdays"] == 999).sum(), round((bank["pdays"] == 999).mean() * 100, 2))

bank_clean = bank.drop_duplicates().reset_index(drop=True)
bank_model = bank_clean.drop(columns="duration")
print(bank_clean.shape, bank_model.shape)

X = bank_model.drop(columns="y")
y = (bank_model["y"] == "yes").astype(int)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y)
numeric_features = X.select_dtypes(include="number").columns.tolist()
categorical_features = X.select_dtypes(exclude="number").columns.tolist()
preprocessor = ColumnTransformer([
    ("num", StandardScaler(), numeric_features),
    ("cat", OneHotEncoder(drop="first", sparse_output=False), categorical_features),
])
X_train_p = preprocessor.fit_transform(X_train)
X_test_p = preprocessor.transform(X_test)
feature_names = [name.split("__", 1)[1] for name in preprocessor.get_feature_names_out()]
print(X_train.shape, X_test.shape)
print(X_train_p.shape, X_test_p.shape)
print(y_train.mean().round(4), y_test.mean().round(4))

target_counts = bank_clean["y"].value_counts()
target_percent = (bank_clean["y"].value_counts(normalize=True) * 100).round(2)
target_table = pd.DataFrame({"Customers": target_counts, "Percent": target_percent})
print(target_table)

plt.figure(figsize=(6, 4.5))
bars = plt.bar(["No", "Yes"], target_counts[["no", "yes"]].values, color=["0.8", "0.25"], edgecolor="black")
for bar, count, pct in zip(bars, target_counts[["no", "yes"]].values, target_percent[["no", "yes"]].values):
    plt.text(bar.get_x() + bar.get_width() / 2, count + 400, f"{count:,} ({pct}%)", ha="center", fontweight="bold")
plt.title("Distribution of Term Deposit Subscription")
plt.xlabel("Subscribed to Term Deposit")
plt.ylabel("Number of Customers")
plt.ylim(0, target_counts.max() * 1.12)
plt.tight_layout()
save_figure("bank_target_distribution")
plt.show()

eda = bank_clean.copy()
eda["subscribed"] = (eda["y"] == "yes").astype(int)
month_order = ["mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
job_rate = (eda.groupby("job")["subscribed"].mean() * 100).sort_values()
month_rate = (eda.groupby("month")["subscribed"].mean() * 100).reindex(month_order)
poutcome_rate = (eda.groupby("poutcome")["subscribed"].mean() * 100).sort_values()
contact_rate = (eda.groupby("contact")["subscribed"].mean() * 100).sort_values()
print(job_rate.round(2))
print(month_rate.round(2))
print(poutcome_rate.round(2))
print(contact_rate.round(2))
print(eda["month"].value_counts().reindex(month_order))
fig, axes = plt.subplots(2, 2, figsize=(13, 9))
axes[0, 0].barh(job_rate.index, job_rate.values, color="0.55", edgecolor="black")
axes[0, 0].set_title("Subscription Rate by Job")
axes[0, 0].set_xlabel("Subscription Rate (%)")
axes[0, 0].set_ylabel("Job")
axes[0, 1].bar(month_rate.index, month_rate.values, color="0.55", edgecolor="black")
axes[0, 1].set_title("Subscription Rate by Contact Month")
axes[0, 1].set_xlabel("Month")
axes[0, 1].set_ylabel("Subscription Rate (%)")
axes[1, 0].bar(poutcome_rate.index, poutcome_rate.values, color="0.55", edgecolor="black")
axes[1, 0].set_title("Subscription Rate by Previous Campaign Outcome")
axes[1, 0].set_xlabel("Previous Campaign Outcome")
axes[1, 0].set_ylabel("Subscription Rate (%)")
axes[1, 1].bar(contact_rate.index, contact_rate.values, color="0.55", edgecolor="black")
axes[1, 1].set_title("Subscription Rate by Contact Type")
axes[1, 1].set_xlabel("Contact Type")
axes[1, 1].set_ylabel("Subscription Rate (%)")
plt.tight_layout()
save_figure("bank_subscription_rates")
plt.show()

selected_numeric = ["age", "campaign", "previous", "euribor3m"]
print(eda.groupby("y")[selected_numeric].mean().round(2))
print(eda.groupby("y")[selected_numeric].median().round(2))
fig, axes = plt.subplots(1, 4, figsize=(15, 4.5))
titles = ["Age", "Number of Contacts in Campaign", "Contacts Before Campaign", "Euribor 3-Month Rate"]
for ax, column, title in zip(axes, selected_numeric, titles):
    sns.boxplot(data=eda, x="y", y=column, ax=ax, color="0.8", linecolor="black", showfliers=False,
                order=["no", "yes"])
    ax.set_title(f"{title} by Outcome", fontsize=10)
    ax.set_xlabel("Subscribed")
    ax.set_ylabel(title)
plt.tight_layout()
save_figure("bank_numeric_boxplots")
plt.show()

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE),
    "Decision Tree": DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=RANDOM_STATE),
    "KNN": KNeighborsClassifier(n_neighbors=15),
    "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=10, min_samples_leaf=5,
                                            class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1),
}
trained = {}
predictions = {}
probabilities = {}
matrices = {}
rows = []
for name, estimator in models.items():
    estimator.fit(X_train_p, y_train)
    trained[name] = estimator
    predictions[name] = estimator.predict(X_test_p)
    probabilities[name] = estimator.predict_proba(X_test_p)[:, 1]
    matrices[name] = confusion_matrix(y_test, predictions[name])
    rows.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, predictions[name]),
        "Precision": precision_score(y_test, predictions[name]),
        "Recall": recall_score(y_test, predictions[name]),
        "F1-Score": f1_score(y_test, predictions[name]),
        "ROC-AUC": roc_auc_score(y_test, probabilities[name]),
    })
comparison = pd.DataFrame(rows).set_index("Model").round(4)
comparison.to_csv("outputs/bank_model_comparison.csv")
print(comparison)

for name in models:
    print(name)
    print(classification_report(y_test, predictions[name], target_names=["No", "Yes"]))

metric_names = ["Accuracy", "Precision", "Recall", "F1-Score"]
bar_shades = ["0.9", "0.65", "0.4", "0.1"]
bar_patterns = ["", "//", "..", "xx"]
positions = np.arange(len(metric_names))
width = 0.2
plt.figure(figsize=(10, 5.5))
for index, name in enumerate(comparison.index):
    values = comparison.loc[name, metric_names].values
    bars = plt.bar(positions + (index - 1.5) * width, values, width, label=name,
                   color=bar_shades[index], edgecolor="black", hatch=bar_patterns[index])
    for bar, value in zip(bars, values):
        plt.text(bar.get_x() + bar.get_width() / 2, value + 0.01, f"{value:.2f}", ha="center", fontsize=8)
plt.xticks(positions, metric_names)
plt.ylim(0, 1.05)
plt.title("Comparison of Classification Models")
plt.xlabel("Evaluation Metric")
plt.ylabel("Score")
plt.legend(loc="upper right", ncol=2)
plt.tight_layout()
save_figure("bank_metric_comparison")
plt.show()

fig, axes = plt.subplots(2, 2, figsize=(10, 9))
for ax, name in zip(axes.ravel(), models):
    draw_confusion(ax, matrices[name], ["No", "Yes"], f"Confusion Matrix - {name}")
    print(name, matrices[name].ravel())
plt.tight_layout()
save_figure("bank_confusion_matrices")
plt.show()

line_styles = ["-", "--", "-.", ":"]
line_shades = ["0.0", "0.35", "0.55", "0.0"]
plt.figure(figsize=(7, 6))
for index, name in enumerate(models):
    fpr, tpr, _ = roc_curve(y_test, probabilities[name])
    plt.plot(fpr, tpr, linestyle=line_styles[index], color=line_shades[index], linewidth=2,
             label=f"{name} (AUC = {comparison.loc[name, 'ROC-AUC']:.3f})")
plt.plot([0, 1], [0, 1], color="0.7", linewidth=1, label="Random Guess (AUC = 0.500)")
plt.title("ROC Curves of the Four Classifiers")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.legend(loc="lower right")
plt.tight_layout()
save_figure("bank_roc_curves")
plt.show()

subscriber_table = pd.DataFrame({
    "Actual Subscribers": [int(matrices[name][1].sum()) for name in models],
    "Correctly Identified": [int(matrices[name][1, 1]) for name in models],
    "Missed": [int(matrices[name][1, 0]) for name in models],
    "Non-subscribers Contacted by Mistake": [int(matrices[name][0, 1]) for name in models],
}, index=list(models))
subscriber_table["Recall (%)"] = (subscriber_table["Correctly Identified"] / subscriber_table["Actual Subscribers"] * 100).round(2)
subscriber_table.to_csv("outputs/bank_subscriber_identification.csv")
print(subscriber_table)
plt.figure(figsize=(9, 4.5))
plt.barh(list(models), subscriber_table["Correctly Identified"], color="0.25", edgecolor="black", label="Correctly identified")
plt.barh(list(models), subscriber_table["Missed"], left=subscriber_table["Correctly Identified"],
         color="0.85", edgecolor="black", hatch="//", label="Missed")
for index, name in enumerate(models):
    plt.text(subscriber_table.loc[name, "Actual Subscribers"] + 8, index,
             f"{subscriber_table.loc[name, 'Recall (%)']}%", va="center", fontweight="bold")
plt.title("Actual Subscribers Identified by Each Model")
plt.xlabel("Number of Actual Subscribers in Test Set")
plt.ylabel("Model")
plt.xlim(0, subscriber_table["Actual Subscribers"].max() * 1.15)
plt.legend(loc="lower right")
plt.tight_layout()
save_figure("bank_subscriber_identification")
plt.show()

ranking = comparison[["Recall", "F1-Score", "ROC-AUC"]].rank(ascending=False).sum(axis=1).sort_values()
print(ranking)
best_model_name = comparison["ROC-AUC"].idxmax()
print(best_model_name)
print(comparison.loc[best_model_name])

importance = pd.Series(trained[best_model_name].feature_importances_, index=feature_names).sort_values(ascending=False)
importance.head(10).to_csv("outputs/bank_feature_importance.csv", header=["Importance"])
print(importance.head(10).round(4))
top_features = importance.head(10).sort_values()
plt.figure(figsize=(8, 5))
plt.barh(top_features.index, top_features.values, color="0.4", edgecolor="black")
plt.title("Top 10 Feature Importances - Random Forest")
plt.xlabel("Importance Score")
plt.ylabel("Feature")
plt.tight_layout()
save_figure("bank_feature_importance")
plt.show()

order = np.argsort(-probabilities[best_model_name])
sorted_actual = y_test.values[order]
captured = np.cumsum(sorted_actual) / sorted_actual.sum()
share_contacted = np.arange(1, len(sorted_actual) + 1) / len(sorted_actual)
gain_rows = []
for share in [0.1, 0.2, 0.3, 0.4, 0.5]:
    position = int(share * len(sorted_actual)) - 1
    gain_rows.append({"Customers Contacted (%)": int(share * 100),
                      "Subscribers Captured (%)": round(captured[position] * 100, 2),
                      "Lift": round(captured[position] / share, 2)})
gain_table = pd.DataFrame(gain_rows)
gain_table.to_csv("outputs/bank_gains.csv", index=False)
print(gain_table)
plt.figure(figsize=(7, 5.5))
plt.plot(share_contacted * 100, captured * 100, color="black", linewidth=2, label=f"{best_model_name}")
plt.plot([0, 100], [0, 100], linestyle="--", color="0.5", label="Random Contact")
plt.title("Cumulative Gains Chart for Customer Targeting")
plt.xlabel("Customers Contacted (%)")
plt.ylabel("Actual Subscribers Captured (%)")
plt.legend(loc="lower right")
plt.tight_layout()
save_figure("bank_gains_chart")
plt.show()
