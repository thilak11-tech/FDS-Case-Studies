# Fundamentals of Data Science - Case Studies

Sanku Thilak | 160124733198 | CSE-3 | III Year

Run: `pip install -r requirements.txt`, open `Case_Studies.ipynb` from this folder, and run all cells.

Web app: `streamlit run app.py`
